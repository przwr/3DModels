/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package merger;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

/**
 *
 * @author Wojtek
 */
public class SpriteCutter {

    public static ImagePlacement getPlacement(String name) {
        try {
            BufferedImage img = ImageIO.read(new File(name));
            int wSt, hSt, wEn, hEn;
            wSt = hSt = wEn = hEn = -1;
            for (int y = 0; y < img.getHeight() && hSt == -1; y++) {
                for (int x = 0; x < img.getWidth(); x++) {
                    if (!isPixelEmpty(img, x, y)) {
                        hSt = y;
                        break;
                    }
                }
            }
            if (hSt != -1) {
                for (int y = img.getHeight() - 1; y >= 0 && hEn == -1; y--) {
                    for (int x = 0; x < img.getWidth(); x++) {
                        if (!isPixelEmpty(img, x, y)) {
                            hEn = y;
                            break;
                        }
                    }
                }
                for (int x = 0; x < img.getWidth() && wSt == -1; x++) {
                    for (int y = 0; y < img.getHeight(); y++) {
                        if (!isPixelEmpty(img, x, y)) {
                            wSt = x;
                            break;
                        }
                    }
                }
                for (int x = img.getWidth() - 1; x >= 0 && wEn == -1; x--) {
                    for (int y = 0; y < img.getHeight(); y++) {
                        if (!isPixelEmpty(img, x, y)) {
                            wEn = x;
                            break;
                        }
                    }
                }
                return new ImagePlacement(wSt, hSt, wEn, hEn, name, img);
            }
        } catch (IOException ex) {
            Merger.error(ex.getMessage());
        }
        return null;
    }

    public static BufferedImage saveToFile(ArrayList<ImagePlacement> imgList, int width, int height) {
        BufferedImage output = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        BufferedImage tmp;
        int imgW = imgList.get(0).getWidth();
        int imgH = imgList.get(0).getHeight();
        int xc = 0;
        int yc = 0;
        for (ImagePlacement img : imgList) {
            tmp = img.getImage();
            Merger.message(img.getName() + " " + xc + ":" + yc + " " + img);
            for (int x = 0; x < imgW; x++) {
                for (int y = 0; y < imgH; y++) {
                    if ((x + img.getxOffset()) > 0 && (y + img.getyOffset()) > 0) {
                        output.setRGB(xc + x, yc + y,
                                tmp.getRGB(x + img.getxOffset(), y + img.getyOffset()));
                    }
                }
            }
            xc += imgW;
            if (xc >= width) {
                xc = 0;
                yc += imgH;
            }
        }
        return output;
    }

    private static boolean isPixelEmpty(BufferedImage img, int x, int y) {
        int rgb = img.getRGB(x, y);
        int c = (rgb >> 6) & 0xff; /*% 0x100;//*/

        return rgb == 0;//c < 5;
    }
}
