/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package merger;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

/**
 *
 * @author Wojtek
 */
public class Merger {

    public static int maxW, padding;
    public static String output, imageFolder, outputFolder;
    public static boolean deleting, cutting, fitting, naming, simplifying;

    public static boolean debug = true;

    static String readSettings(String file) throws Exception {
        BufferedReader read = new BufferedReader(new FileReader("settings.txt"));
        String line = read.readLine();
        imageFolder = line;
        line = read.readLine();
        String exOutput = line;
        line = read.readLine();
        naming = line.equals("1");
        line = read.readLine();
        deleting = line.equals("1");
        line = read.readLine();
        cutting = line.equals("1");
        line = read.readLine();
        fitting = line.equals("1");
        line = read.readLine();
        simplifying = line.equals("1");
        line = read.readLine();
        outputFolder = line;
        return exOutput;
    }

    public static void main(String[] args) {
        String exOutput;
        // CZYTANIE USTAWIEN ---------------------------------------------------
        try {
            exOutput = readSettings("settings.txt");
        } catch (Exception ex) {
            error(ex.getMessage());
            return;
        }

        // WCZYTYWANIE OBRAZKOW ------------------------------------------------
        String[] images;
        File dir = new File(imageFolder);
        if (dir.exists() && dir.isDirectory()) {
            images = dir.list((File image, String name) -> name.endsWith(".png"));
        } else {
            error("TO NIE MA SENSU, " + imageFolder + " TO NIE JEST FOLDER!");
            return;
        }

        // WYMIARY OBRAZKOW ----------------------------------------------------
        int iWidth, iHeight;
        try {
            BufferedImage buffImg = ImageIO.read(new File(imageFolder + "\\" + images[0]));
            iWidth = buffImg.getWidth();
            iHeight = buffImg.getHeight();
        } catch (IOException ex) {
            error("Testing dimesions : " + ex.getMessage());
            return;
        }

        // WYZNACZANIE PRZYCIEC ------------------------------------------------
        ArrayList<ImagePlacement> imagePlaces = new ArrayList<>();
        ImagePlacement tmpPlace;
        ImagePlacement dims = null;
        int maxWidth = 0;
        int maxHeight = 0;
        for (String image : images) {
            if (cutting) {
                tmpPlace = SpriteCutter.getPlacement(imageFolder + "\\" + image);
            } else {
                try {
                    tmpPlace = new ImagePlacement(0, 0, iWidth, iHeight, imageFolder + "\\" + image);
                } catch (IOException ex) {
                    error("TO NIE MA SENSU, " + imageFolder + "\\" + image + " NIE MA TAKIEGO OBRAZKA!");
                    return;
                }
            }
            if (dims == null) {
                dims = new ImagePlacement(tmpPlace);
            } else {
                dims.mergeWith(tmpPlace);
            }
            imagePlaces.add(tmpPlace);
            message(image + " " + tmpPlace);
            if (tmpPlace.getWidth() > maxWidth) {
                maxWidth = tmpPlace.getWidth();
            }
            if (tmpPlace.getHeight() > maxHeight) {
                maxHeight = tmpPlace.getHeight();
            }
        }

        // ROZMIARY KLATKI -----------------------------------------------------
        int tmpW = 2;
        int tmpH = 2;
        message(maxWidth + " " + maxHeight);
        while (maxWidth > tmpW) {
            tmpW *= 2;
        }
        while (maxHeight > tmpH) {
            tmpH *= 2;
        }
        maxWidth = tmpW;
        maxHeight = tmpH;
        ImagePlacement tempIP;
        boolean fits;
        int j = 0;
        ArrayList<ImagePlacement> sameyOnes = new ArrayList<>();
        for (int i = 0; i < imagePlaces.size(); i++) {
            tempIP = imagePlaces.get(i);
            tempIP.changeWidth(maxWidth, iWidth);
            tempIP.changeHeight(maxHeight, iHeight);
            fits = false;
            for (j = 0; j < sameyOnes.size(); j++) {
                if (tempIP.equalsTo(sameyOnes.get(j))) {
                    fits = true;
                    break;
                }
            }
            if (fits) {
                message(i + " " + tempIP + " -> " + sameyOnes.get(j));
                tempIP.changeTo(sameyOnes.get(j));
                tempIP.replace(sameyOnes.get(j).getIndex());
            } else {
                tempIP.setIndex(i);
                sameyOnes.add(tempIP);
            }
        }
        message(maxWidth + " " + maxHeight);

        // WYBRANIE NAZWY ------------------------------------------------------
        int i = 0;
        if (naming) {
            exOutput = NameRater.getImageName(exOutput);
        }
        while (new File(exOutput + (i > 0 ? i : "") + ".png").exists()) {
            i++;
        }
        output = exOutput + (i > 0 ? i : "");

        // WIELKOSC OBRAZKA ----------------------------------------------------
        int wholeW = maxWidth;
        int wholeH = maxHeight;
        int imagesArea = images.length * maxHeight * maxWidth;
        message("images area: " + imagesArea);
        while (imagesArea > wholeW * wholeH) {
            if (wholeW >= wholeH) {
                wholeH *= 2;
            } else {
                wholeW *= 2;
            }
            message("area: " + (wholeW * wholeH));
        }
        message(wholeW + " " + wholeH + " act: " + images.length + " " + maxWidth + " " + maxW);

        // ZAPIS ---------------------------------------------------------------
        try {
            ImageIO.write(SpriteCutter.saveToFile(imagePlaces, wholeW, wholeH), "PNG", new File(output + ".png"));
            saveSprFile(wholeW, wholeH, maxWidth, maxHeight, dims, images, imagePlaces);
            if (deleting) {
                for (i = 0; i < images.length; i++) {
                    try {
                        Files.delete(new File(imageFolder + "\\" + images[i]).toPath());
                    } catch (IOException ex) {
                        Logger.getLogger(Merger.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        } catch (IOException ex) {
            error(ex.getMessage());
        }
    }

    static void saveSprFile(int imageWidth, int imageHeight, int tileWidth, int tileHeight,
            ImagePlacement realSpriteDimensions, String[] images, ArrayList<ImagePlacement> imagePlaces)
            throws FileNotFoundException {
        int lastXOff = 0;
        int lastYOff = 0;
        int offCount = 0;
        System.out.println(outputFolder);
        try (PrintWriter save = new PrintWriter((outputFolder == null ? "" : outputFolder) + output + ".spr")) {
            save.println(output + ";1");
            save.println(output + ".png");
            save.println(imageWidth + ";" + imageHeight);
            save.println("0;0");
            save.println(tileWidth + ";" + tileHeight);
            boolean theSame = true;
            ImagePlacement first = imagePlaces.get(0);
            for (ImagePlacement img : imagePlaces) {
                if (first.getxOffset() != img.getxOffset() || first.getyOffset() != img.getyOffset()) {
                    theSame = false;
                    break;
                }
            }
            save.println(realSpriteDimensions.getxOffset() + ";" + realSpriteDimensions.getyOffset()
                    + ";" + realSpriteDimensions.getWidth() + ";" + realSpriteDimensions.getHeight());
            if (!theSame) {
                save.println(images.length);
                for (ImagePlacement img : imagePlaces) {
                    if (simplifying) {
                        if (img.getxOffset() == lastXOff && img.getyOffset() == lastYOff) {
                            offCount++;
                        } else {
                            if (offCount == 1) {
                                save.println(lastXOff + ";" + lastYOff);
                            } else if (offCount > 1) {
                                save.println("r;" + offCount);
                            }
                            if (!img.isReplaced()) {
                                save.println(img.getxOffset() + ";" + img.getyOffset());
                            } else {
                                save.println("s;" + img.getReplaceIndex());
                            }
                            offCount = 0;
                            lastXOff = img.getxOffset();
                            lastYOff = img.getyOffset();
                        }
                    } else {
                        save.println(img.getxOffset() + ";" + img.getyOffset());
                    }
                }
                if (offCount > 1) {
                    save.println(lastXOff + ";" + lastYOff);
                    save.println("r;" + (offCount - 1));
                }
            }
            save.close();
        }
    }

    public static void message(String m) {
        if (debug) {
            System.out.println(m);
        }
    }

    public static void error(String m) {
        JOptionPane.showMessageDialog(null, m, "ERROR!", JOptionPane.ERROR_MESSAGE);
    }

}
