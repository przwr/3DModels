/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package merger;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author Wojtek
 */
public class ImagePlacement {

    private int xBegin;
    private int yBegin;
    private int xEnd;
    private int yEnd;
    
    private final String name;
    private final BufferedImage image;
    
    private int replaced;
    private int index;

    public ImagePlacement(int xBegin, int yBegin,
            int xEnd, int yEnd, String name, BufferedImage image) {
        this.xBegin = xBegin;
        this.yBegin = yBegin;
        this.xEnd = xEnd;
        this.yEnd = yEnd;
        this.name = name;
        this.image = image;
        replaced = -1;
    }
    
    public ImagePlacement(ImagePlacement ip) {
        this.xBegin = ip.xBegin;
        this.yBegin = ip.yBegin;
        this.xEnd = ip.xEnd;
        this.yEnd = ip.yEnd;
        this.name = "";
        this.image = null;
        replaced = -1;
    }
    
    public ImagePlacement(int xBegin, int yBegin,
            int xEnd, int yEnd, String name) throws IOException {
        this.xBegin = xBegin;
        this.yBegin = yBegin;
        this.xEnd = xEnd;
        this.yEnd = yEnd;
        this.name = name;
        this.image = ImageIO.read(new File(name));
        replaced = -1;
    }

    public void setIndex(int index) {
        this.index = index;
    }
        
    public int getIndex() {
        return index;
    }
    
    public BufferedImage getImage() {
        return image;
    }
    
    public void replace(int index) {
        replaced = index;
    }
    
    public boolean isReplaced() {
        return replaced >= 0;
    }
    
    public int getReplaceIndex() {
        return replaced;
    }
    
    public boolean equalsTo(ImagePlacement ip) {
        return xBegin == ip.xBegin && yBegin == ip.yBegin;
    }
    
    public void changeTo(ImagePlacement ip) {
        xBegin = ip.xBegin;
        xEnd = ip.xEnd;
        yBegin = ip.yBegin;
        yEnd = ip.yEnd;
    }
    
    public void changeWidth(int w, int wholeW) {
        int d = (w - xEnd + xBegin - 1) / 2;
        int r = (w - xEnd + xBegin - 1) % 2;
        xBegin -= d + r;
        xEnd += d;
        if (xBegin < 0) {
            xEnd -= xBegin;
            xBegin = 0;
        }
        if (xEnd >= wholeW) {
            xBegin -= xEnd - wholeW + 1;
            xEnd = wholeW - 1;
        }
    }

    public void changeHeight(int h, int wholeH) {
        int d = (h - yEnd + yBegin - 1) / 2;
        int r = (h - yEnd + yBegin - 1) % 2;
        yBegin -= d + r;
        yEnd += d;
        if (yBegin < 0) {
            yEnd -= yBegin;
            yBegin = 0;
        }
        if (yEnd >= wholeH) {
            yBegin -= yEnd - wholeH + 1;
            yEnd = wholeH - 1;
        }
    }

    public void mergeWith(ImagePlacement ip) {
        if (ip != null) {
            if (xBegin > ip.xBegin) {
                xBegin = ip.xBegin;
                Merger.message("  " + xBegin);
            }
            if (yBegin > ip.yBegin) {
                yBegin = ip.yBegin;
                Merger.message("  " + yBegin);
            }
            if (xEnd < ip.xEnd) {
                xEnd = ip.xEnd;
                Merger.message("  " + xEnd);
            }
            if (yEnd < ip.yEnd) {
                yEnd = ip.yEnd;
                Merger.message("  " + yEnd);
            }
        }
    }

    public int getxOffset() {
        return xBegin;
    }

    public int getyOffset() {
        return yBegin;
    }

    public int getWidth() {
        return xEnd - xBegin + 1;
    }

    public int getHeight() {
        return yEnd - yBegin + 1;
    }

    public int getXEnd() {
        return xEnd;
    }

    public int getYEnd() {
        return yEnd;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "(" + xBegin + ", " + yBegin + ") [" + getWidth() + ", " + getHeight() + "]";
    }
}
